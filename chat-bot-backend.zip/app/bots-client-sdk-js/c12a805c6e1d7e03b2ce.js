webpackJsonp([190],{776:function(e,t,d){"use strict";function r(e,t,d,r){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=r;var o={lastWeek:"[sidste] dddd [kl.] LT",yesterday:"[i går kl.] LT",today:"[i dag kl.] LT",tomorrow:"[i morgen kl.] LT",nextWeek:"[på] dddd [kl.] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=c12a805c6e1d7e03b2ce.js.map
