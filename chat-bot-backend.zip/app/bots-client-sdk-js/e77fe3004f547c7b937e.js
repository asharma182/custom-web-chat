webpackJsonp([50],{918:function(e,t,o){"use strict";function d(e,t,o,d){return r[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=d;var r={lastWeek:"dddd [tuần trước vào lúc] LT",yesterday:"[hôm qua vào lúc] LT",today:"[hôm nay vào lúc] LT",tomorrow:"[ngày mai vào lúc] LT",nextWeek:"dddd [vào lúc] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=e77fe3004f547c7b937e.js.map
